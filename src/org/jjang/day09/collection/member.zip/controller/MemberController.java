package org.jjang.day09.collection.member.controller;

public class MemberController {
	// Member List를 저장소로 가지고 있으며 추가, 수정, 삭제, 출력하는 메소드 작성
	// addMember, updateMember, deleteMember, findMember, findAllMember
}
