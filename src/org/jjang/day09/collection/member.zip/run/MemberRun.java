package org.jjang.day09.collection.member.run;

public class MemberRun {

}
