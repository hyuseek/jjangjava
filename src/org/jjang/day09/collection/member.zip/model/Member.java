package org.jjang.day09.collection.member.model;

public class Member {
	// memberId
	// memberPw
	// memberName
	// memberEmail
	// memberPhone
}
